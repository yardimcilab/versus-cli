The versus-cli tool reads a list of strings from stdin, forms A vs. B combinations, and formats and runs commands on them.

Versus-cli is part of the Wistan platform. Like all Wistan infrastructure, it can be used on its own independently of the rest of Wistan.
